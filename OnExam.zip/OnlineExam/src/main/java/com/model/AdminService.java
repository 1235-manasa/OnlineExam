package com.model;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class AdminService {

    @Autowired
    AdminDAO adminDAOImpl;
    @Autowired
    QuestionService questionService;
    @Autowired
    User_ans useransService;
    
    @Autowired
    SessionFactory sessionFactory;

    public void login(Admin admin)
       {
           adminDAOImpl.login(admin);
       }
    public void update(Admin admin)
       {
           adminDAOImpl.update(admin);
       }
    public void create(Admin admin)
       {
           adminDAOImpl.create(admin);
       }
    public void report(Admin admin)
       {
           adminDAOImpl.report(admin);
           
       }
    public int getall(int id){
    	return adminDAOImpl.getScore(id);
    }
    
//    uid
//    qid
//    anis
//    sc
//    session(s);
    
 
}
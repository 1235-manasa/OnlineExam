package com.model;

public class DatanotfoundException extends Exception 
	{
		
	}


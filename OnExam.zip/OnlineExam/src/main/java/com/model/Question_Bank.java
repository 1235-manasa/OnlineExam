package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Question_Bank {
@Id
int Q_B_Id;
int Test_Id;
int Q_Id;
public int getQ_B_Id() {
	return Q_B_Id;
}
public void setQ_B_Id(int q_B_Id) {
	Q_B_Id = q_B_Id;
}
public int getTest_Id() {
	return Test_Id;
}
public void setTest_Id(int test_Id) {
	Test_Id = test_Id;
}
public int getQ_Id() {
	return Q_Id;
}
public void setQ_Id(int q_Id) {
	Q_Id = q_Id;
}
public Question_Bank(int q_B_Id, int test_Id, int q_Id) {
	super();
	Q_B_Id = q_B_Id;
	Test_Id = test_Id;
	Q_Id = q_Id;
}
}


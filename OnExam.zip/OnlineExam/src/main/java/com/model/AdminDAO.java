package com.model;

import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public interface AdminDAO {

    public void login(Admin admin);
    public Admin find(int id);
    public String initData();
    public void update(Admin admin);
    public void create(Admin admin);
    public void report(Admin admin);
	public int getScore(int id);
	public String adminValid(int id, String password);

	

 
}
package com.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface UserDAO {
	public void saveUser(Users user);
	public Users findUser(int id);
	public List<Users> findAll();
	public boolean update(Users user);
	public boolean delete(Users user);
	public List<Users> findAllUsers(String name);
}

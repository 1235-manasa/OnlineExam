package com.model;
import java.util.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.h2.engine.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
@Entity
@Table(name="Result")
public class Result {
@Id
@GeneratedValue
private int UserId;
private int TestId;
private int QuestionId;
private Date Examdate;
private int score;
@ManyToMany
List<Users> userList =new ArrayList<Users>();


public void addUser(Users u) {
userList.add(u);
}
public void removeUser(Users c)
{
userList.remove(c);
}
public int getUserId() {
return UserId;
}
public void setUserId(int userId) {
this.UserId = userId;
}
public int getTestId() {
return TestId;
}
public void setTestId(int testId) {
this.TestId = testId;
}
public int getQuestionId() {
return QuestionId;
}
public void setQuestionId(int questionId) {
this.QuestionId = questionId;
}
public Date getExamdate() {
return Examdate;
}
public void setExamdate(Date examdate) {
this.Examdate = examdate;
}


/*public int getScore(){
	
		return AdminDAOImpl.getScore();

}*/

/*public void setExamscore(int examscore) {
this.Examscore = examscore;
}*/
public List<Users> getUserList() {
return userList;
}
public void setUserList(List<Users> userList) {
this.userList = userList;
}
/*public TestManagement getTestManagement() {
return testmanagement;
}
public void setTestManagement(TestManagement testmanagement) {
this.testmanagement = testmanagement;
}*/



public Result(int userId, int testId, int questionId, Date examdate, int score) {
this.UserId = userId;
this.TestId = testId;
this.QuestionId = questionId;
this.Examdate = examdate;
this.score = score;
}
public Result() {
}
}



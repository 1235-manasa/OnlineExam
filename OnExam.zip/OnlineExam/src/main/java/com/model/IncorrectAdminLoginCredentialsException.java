package com.model;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus
public class IncorrectAdminLoginCredentialsException extends RuntimeException {
 
    private static final long serialVersionUID = 1L;
 
    public IncorrectAdminLoginCredentialsException(String message) {
        super(message);
    }
}

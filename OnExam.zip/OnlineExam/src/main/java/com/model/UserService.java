package com.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	@Autowired
	UserDAO UserDAOImpl;
	@Autowired
	AdminDAO adminDAOImpl;
	
	   public void save(Users user)
	   {
		   UserDAOImpl.saveUser(user);
	   }
	   public List<Users> getAll()
	   {
		   return UserDAOImpl.findAll();
	   }
	   public boolean update(Users user)
	   {
		  return  UserDAOImpl.update(user);
	   }
	   public boolean  delete(int id)
	   {
		   Users item=UserDAOImpl.findUser(id);
		   return UserDAOImpl.delete(item);
	   }

}

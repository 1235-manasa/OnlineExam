package com.model;
import javax.persistence.Entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
@Entity
@Table(name="Users")
public class Users {
@Id
@GeneratedValue
private int id;
private String name;
private String address;
private String mail;
private String password;
@ManyToMany
List<Result> rList=new ArrayList<Result>();
public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public String getAddress() {
return address;
}
public void setAddress(String address) {
this.address = address;
}
public String getMail() {
return mail;
}
public void setMail(String mail) {
this.mail = mail;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}


public Users(int id, String name, String address, String mail,String password) {
super();
this.id = id;
this.name = name;
this.address = address;
this.mail = mail;
this.password=password;
}
public Users() {
super();
}

@Override
public String toString() {
	return "Users [id=" + id + ", name=" + name + ", address=" + address + ", mail=" + mail + ", password=" + password
			+ ", rList=" + rList + "]";
}
}

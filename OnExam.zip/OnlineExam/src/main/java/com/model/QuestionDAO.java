package com.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface QuestionDAO {

  //  public Question getAll(Question questions);
	public List<Question> findAll();
	public void getQuestion(Question question);
	public String postQuestion();
	public String postAnswer(String userans);
 
}
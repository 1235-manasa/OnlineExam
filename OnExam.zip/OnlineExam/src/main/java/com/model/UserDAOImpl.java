package com.model;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserDAOImpl implements UserDAO{

	@Autowired 
	SessionFactory sessionFactory;
	@Override
	public void saveUser(Users user) {
		Session session=sessionFactory.openSession();
		Transaction tx = session.beginTransaction();  
		session.save(user);
		session.flush();
		session.close();
		tx.commit();
		// TODO Auto-generated method stub
		
	}
	public String userValid(int id,String password) throws IncorrectLoginCredentialsException 
    {
        Session session=sessionFactory.openSession();
        Transaction tx=session.beginTransaction();
        Users u=session.find(Users.class, id);
       try{
            if(!(u.getPassword().equals(password)))
            {
                return "Try again";
            }
            else
                {
                    return "Login Successful";   
                }
        }
        catch(IncorrectLoginCredentialsException e)
       {
        	System.out.println(e.getMessage());
        }
		return null;
    }

	@Override
	public Users findUser(int id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
        Users users=session.get(Users.class, id);
        return users;
		
	}

	@Override
	public List<Users> findAll() {
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Query query=session.createQuery("select i from Users i");
		
		List<Users> userlist=query.list();
		session.flush();
		session.close();
		tx.commit();
		return userlist;
	}

	@Override
	public boolean update(Users user) {
	
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Users y=session.find(Users.class, user.getId());
//		u.setPassword);
		String h=user.getPassword();
		y.setPassword(h);
		session.update(y);
		session.flush();
		session.close();
		tx.commit();
		// TODO Auto-generated method stub
		return true;
	}
//	@Override
	public List<Users> findAllUsers(String name) {
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Query q=session.createQuery("select i from User i");
		List<Users> u=q.list();
		List<Users> al=new ArrayList<Users>();
		for(Users i:u)
		{
			if(i.getName()==name)
			{
				al.add(i);
			}
		}
		session.flush();
		session.close();
		tx.commit();
		// TODO Auto-generated method stub
		return al;
		
	}

	@Override
	public boolean delete(Users user) {
		// TODO Auto-generated method stub
		return false;
	}

}

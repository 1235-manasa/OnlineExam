package com.model;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.*;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class AdminDAOImpl implements AdminDAO {
	@Autowired 
	SessionFactory sessionFactory;
    @Override
    public void login(Admin admin) {
        // TODO Auto-generated method stub
    	Session session=sessionFactory.openSession();
		Transaction tx = session.beginTransaction();   
		session.save(admin);
		session.flush();
		session.close();
		tx.commit();
 
    }
    @Override
    public String initData()
    {
    	Session session=sessionFactory.openSession();
    	Transaction tx = session.beginTransaction();
		Query q=session.createQuery("select i from Admin i");
		List<Admin> u=q.list();
		List<Admin> al=new ArrayList<Admin>();
		for(Admin i:u)
		{
			if(i.getName() != null)
			{
				return "true";
			}
		}
		session.flush();
		session.close();
		tx.commit();
		// TODO Auto-generated method stub
		return "false";
    }
    @Override
    public Admin find(int id) {
        Session session=sessionFactory.openSession();
        Admin admin=session.get(Admin.class,id);
        return admin;
        // TODO Auto-generated method stub
 
    }
 
    @Override
    public void update(Admin admin) {
        // TODO Auto-generated method stub
    	
 
    }
 
    @Override
    public void create(Admin admin) {
        // TODO Auto-generated method stub
 
    }
 
    @Override
    public void report(Admin admin) {
        // TODO Auto-generated method stub
 
    }
    
    @Override
    public  int getScore(int id){
    	Session session=sessionFactory.openSession();
    	Transaction tx=session.beginTransaction();
    	Query query=session.createQuery("select i from Question i");
    	List<Question> g=query.list();
    	System.out.println(g);
    	List<String> h=new ArrayList<String>();
    	int y=1, score=0;
    	
    	for(int i=0;i<g.size();i++)
    	{
    		if(y%2==i)
    		{
    			h.add(g.get(i).getUserans());
    			y+=2;
    		}
    	}
    	for(String i:h)
    	{
    		if(i.equals("Apple"))
    		{
    			score++;
    		}
    	}
    	session.close();
    	tx.commit();
    	return score;
    }
    public String adminValid(int id,String password) throws IncorrectAdminLoginCredentialsException 
    {
        Session session=sessionFactory.openSession();
        Transaction tx=session.beginTransaction();
        Admin u=session.find(Admin.class, id);
       try{
            if(!(u.getPassword().equals(password)))
            {
                return "Try again";
            }
            else
                {
                    return "Admin Login Successful";   
                }
        }
        catch(IncorrectAdminLoginCredentialsException e)
       {
        	System.out.println(e.getMessage());
        }
		return null;
    }
   
  
    
}
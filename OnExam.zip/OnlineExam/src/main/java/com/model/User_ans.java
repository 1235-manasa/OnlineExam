package com.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class User_ans {
	@Autowired
	QuestionService service;
	int qid;
	String userans;
public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}




public String getUserans() {
	return userans;
}

public void setUserans(String userans) {
	this.userans = userans;
}

public User_ans(String userans,int qid) {
	super();
	this.userans = userans;
	this.qid=qid;
}

public User_ans() {
	
}


}

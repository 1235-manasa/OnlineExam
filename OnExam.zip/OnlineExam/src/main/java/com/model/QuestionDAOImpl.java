package com.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QuestionDAOImpl implements QuestionDAO {
	
	@Autowired 
	SessionFactory sessionFactory;

	

	public void getQuestion(Question question) {
		Session session=sessionFactory.openSession();
		Transaction tx = session.beginTransaction();	
		session.save(question);
		session.flush();
		session.close();
		tx.commit();
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Question> findAll() {
			Session session=sessionFactory.openSession();
			Transaction tx=session.beginTransaction();
			Query query=session.createQuery("select i from Question i");
			List<Question> questionlist=query.list();
			session.flush();
			session.close();
			tx.commit();
			// TODO Auto-generated method stub
			
			return questionlist;
		
	}
	
	@Override
	public String postQuestion()
	{
		Session session=sessionFactory.openSession();
		Transaction tx = session.beginTransaction();	
		 String q1= "who created java?";
	     String op1= "Apple";
	     String op2= "Sunmicrosystems";
	     String op3= "Microsoft";
	     String op4= "Starbucks";
	    Question q=new Question(q1, op1, op2, op3, op4);
	    session.save(q);
	    session.flush();
	    session.close();
	    tx.commit();
		return "Questons Added";
		}
	@Override
	public String postAnswer(String userans)
	{
		Session session=sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Question q=new Question(userans);
		session.save(q);
	    session.flush();
	    session.close();
	    tx.commit();
	    return "Ans saved";
		
	}
}

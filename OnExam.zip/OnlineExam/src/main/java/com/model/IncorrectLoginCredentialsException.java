package com.model;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus
public class IncorrectLoginCredentialsException extends RuntimeException {
 
    private static final long serialVersionUID = 1L;
 
    public IncorrectLoginCredentialsException(String message) {
        super(message);
    }
}
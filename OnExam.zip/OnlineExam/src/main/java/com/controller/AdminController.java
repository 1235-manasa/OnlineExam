package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
 
import com.model.Admin;
import com.model.AdminDAO;
import com.model.AdminService;
import com.model.IncorrectAdminLoginCredentialsException;
import com.model.IncorrectLoginCredentialsException;
import com.model.Question;
import com.model.QuestionService;
import com.model.Users;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
 
@RestController
@RequestMapping("Admin")
@Api(value = "AdminController", description = "Description for Admin Controller")
public class AdminController {


    @Autowired
    AdminService service;
    @Autowired
    QuestionService questionService;
    @Autowired
    AdminDAO adminDAOservice;


    @PostMapping("saveadmin")
     @ApiOperation(value = "Save admin", httpMethod = "POST")
    public ResponseEntity<?> saveAdmin(@RequestBody Admin admin)
    {
        service.login(admin);
       return ResponseEntity.ok(admin+" saved");
    }
    @GetMapping("getscore")
    @ResponseBody
      @ApiOperation(value = "Get Score ", httpMethod = "GET")
    public ResponseEntity<?> getAllScore(int id) throws DataNotFoundException
    {
    	try
    	{
    	int score=service.getall(id);
    	if(score==0)
    	{
    	throw new DataNotFoundException("No score");
    	}
    	else
    	{
    		return new ResponseEntity(score,HttpStatus.OK);
    	}
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
		return null;
    	
    }
    @PostMapping("Admin/login")
    @ResponseBody
    @ApiOperation(value = "Admin login", httpMethod = "POST")
    public ResponseEntity<?> userValidation(@RequestBody int id, String password) throws IncorrectAdminLoginCredentialsException
    {
        return new ResponseEntity(adminDAOservice.adminValid(id, password) ,HttpStatus.OK);
    }
}
package com.controller;

public class NoQuestionFoundException extends Exception {
	public NoQuestionFoundException(String str)
	{
		super(str);
	}

}

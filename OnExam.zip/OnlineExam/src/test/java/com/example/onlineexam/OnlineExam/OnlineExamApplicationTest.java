package com.example.onlineexam.OnlineExam;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.model.Admin;
import com.model.AdminDAO;
import com.model.UserDAO;
import com.model.Users;

@SpringBootTest
class OnlineExamApplicationTest {
	@Autowired
    AdminDAO adminDAOImpl;
	@Autowired
    UserDAO userDAOImpl;
	
	
	@Test
	void userWithSameName2() {
		assertThat(true).isNotEqualTo(adminDAOImpl.initData());
	}
	@Test
	void userWithSameName3() {
		assertThat(true).isNotEqualTo(adminDAOImpl.find(1));
	}
	@Test
	void userWithSameName4() {
		assertThat(true).isNotEqualTo(adminDAOImpl.adminValid(12,"5678"));
	}
//	@Test
//	void userWithSameName5() {
//		assertThat(true).isNotEqualTo(adminDAOImpl.getScore(5));
//	}
	@Test
	void userWithSameName6() {
		assertThat(true).isNotEqualTo(userDAOImpl.findUser(1));
	}
	
	@Test
	void userWithSameName1()
	{
	List<Users> ul=userDAOImpl.findAll();
    int c=0;
    assertThat(c).isNotEqualTo(ul.size());
	}
	@Test
	 void dataInDB()
	 {
		 assertThat("true").isEqualTo(adminDAOImpl.initData());

}
	

}
